﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phineas_y_Ferb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int a = 0;
        int f = 0;
        int p = 0;
        int fer = 0;
        int phi = 0;
        int cuenta = 0;

        private void btnAgrearIdea_Click(object sender, EventArgs e)
        {
            string autor = txtAutor.Text;
            int cant = Convert.ToInt32(txtCant.Text);
            if (autor=="f" || autor=="F")
            {
                f = f + cant;
                fer = cant + fer;
            }
            else if (autor == "p" || autor == "P")
            {
                p = p + cant;
                phi = cant + phi;
            }
            else
            {
                a = a + cant;
            }
            MessageBox.Show("La idea fue guardada");
        }

        private void btnConstruirInvento_Click(object sender, EventArgs e)
        {
            cuenta++;
            if (a >=1)
            {
                MessageBox.Show("Hay que construir la idea de algún amigo!!");
                a--;
            }
            else if (cuenta % 2 ==0 && f > 0)
            {
                MessageBox.Show("Hay que construir la idea de Ferb!!");
                f--;
            }
            else if (cuenta % 2 != 0 && p > 0)
            {
                MessageBox.Show("Hay que construir la idea de Phineas!!");
                p--;
            }
            else if (f > 0 && p <= 0)
            {
                MessageBox.Show("Hay que construir la idea de Ferb!!");
                f--;
            }
            else if (p > 0 && f <= 0)
            {
                MessageBox.Show("Hay que construir la idea de Phineas!!");
                p--;
            }
            else
            {
                MessageBox.Show("No hay mád ideas, tienen un merecido descanso");
            }
        }

        private void btnIdeasFaltantes_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Faltan " + a + " ideas de amigos, " + f + " ideas de Ferb y " + p + " ideas de Phineas");
        }

        private void btnMasInventos_Click(object sender, EventArgs e)
        {
            fer = fer - f;
            phi = phi - p;
           if (fer >phi)
            {
                MessageBox.Show("Se construyeron más ideas de Ferb!!"); 
            }
            else if (fer < phi)
            {
                MessageBox.Show("Se construyeron más ideas de Phineas!!");
            }
           else
            {
                MessageBox.Show("Se construyeron la misma cantidad de ideas!!");
            }
        }
    }
}
