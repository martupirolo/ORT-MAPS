﻿
namespace Phineas_y_Ferb
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnAgrearIdea = new System.Windows.Forms.Button();
            this.btnConstruirInvento = new System.Windows.Forms.Button();
            this.btnIdeasFaltantes = new System.Windows.Forms.Button();
            this.btnMasInventos = new System.Windows.Forms.Button();
            this.txtCant = new System.Windows.Forms.TextBox();
            this.txtAutor = new System.Windows.Forms.TextBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Phineas_y_Ferb.Properties.Resources.phineas_y_ferb_11;
            this.pictureBox2.Location = new System.Drawing.Point(-1, -10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(700, 521);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // btnAgrearIdea
            // 
            this.btnAgrearIdea.BackColor = System.Drawing.Color.Blue;
            this.btnAgrearIdea.Location = new System.Drawing.Point(481, 54);
            this.btnAgrearIdea.Name = "btnAgrearIdea";
            this.btnAgrearIdea.Size = new System.Drawing.Size(113, 40);
            this.btnAgrearIdea.TabIndex = 1;
            this.btnAgrearIdea.Text = "Ya se que vamos\r\na hacer hoy!!!";
            this.btnAgrearIdea.UseVisualStyleBackColor = false;
            this.btnAgrearIdea.Click += new System.EventHandler(this.btnAgrearIdea_Click);
            // 
            // btnConstruirInvento
            // 
            this.btnConstruirInvento.BackColor = System.Drawing.Color.Red;
            this.btnConstruirInvento.Location = new System.Drawing.Point(279, 381);
            this.btnConstruirInvento.Name = "btnConstruirInvento";
            this.btnConstruirInvento.Size = new System.Drawing.Size(83, 74);
            this.btnConstruirInvento.TabIndex = 2;
            this.btnConstruirInvento.Text = "CONSTRUIR \r\nINVENTO\r\n";
            this.btnConstruirInvento.UseVisualStyleBackColor = false;
            this.btnConstruirInvento.Click += new System.EventHandler(this.btnConstruirInvento_Click);
            // 
            // btnIdeasFaltantes
            // 
            this.btnIdeasFaltantes.BackColor = System.Drawing.Color.Yellow;
            this.btnIdeasFaltantes.Location = new System.Drawing.Point(12, 161);
            this.btnIdeasFaltantes.Name = "btnIdeasFaltantes";
            this.btnIdeasFaltantes.Size = new System.Drawing.Size(104, 46);
            this.btnIdeasFaltantes.TabIndex = 3;
            this.btnIdeasFaltantes.Text = "¿Cuantas ideas\r\nfaltan?";
            this.btnIdeasFaltantes.UseVisualStyleBackColor = false;
            this.btnIdeasFaltantes.Click += new System.EventHandler(this.btnIdeasFaltantes_Click);
            // 
            // btnMasInventos
            // 
            this.btnMasInventos.BackColor = System.Drawing.Color.Yellow;
            this.btnMasInventos.Location = new System.Drawing.Point(12, 336);
            this.btnMasInventos.Name = "btnMasInventos";
            this.btnMasInventos.Size = new System.Drawing.Size(104, 53);
            this.btnMasInventos.TabIndex = 4;
            this.btnMasInventos.Text = "¿De quién se construyeron\r\nmás inventos?";
            this.btnMasInventos.UseVisualStyleBackColor = false;
            this.btnMasInventos.Click += new System.EventHandler(this.btnMasInventos_Click);
            // 
            // txtCant
            // 
            this.txtCant.Location = new System.Drawing.Point(309, 74);
            this.txtCant.Name = "txtCant";
            this.txtCant.Size = new System.Drawing.Size(100, 20);
            this.txtCant.TabIndex = 5;
            // 
            // txtAutor
            // 
            this.txtAutor.BackColor = System.Drawing.Color.White;
            this.txtAutor.Location = new System.Drawing.Point(113, 74);
            this.txtAutor.Name = "txtAutor";
            this.txtAutor.Size = new System.Drawing.Size(100, 20);
            this.txtAutor.TabIndex = 6;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.SystemColors.Window;
            this.lbl2.Location = new System.Drawing.Point(314, 30);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(95, 26);
            this.lbl2.TabIndex = 7;
            this.lbl2.Text = "Cantidad de ideas:\r\n\r\n";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.SystemColors.Window;
            this.lbl1.Location = new System.Drawing.Point(99, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(143, 52);
            this.lbl1.TabIndex = 8;
            this.lbl1.Text = "Inicial del autor\r\nSi es Ferb, ingresar F\r\nSi es Phineas, ingresar P\r\nSi es algún" +
    " amigo, ingresar A";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(699, 510);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.txtAutor);
            this.Controls.Add(this.txtCant);
            this.Controls.Add(this.btnMasInventos);
            this.Controls.Add(this.btnIdeasFaltantes);
            this.Controls.Add(this.btnConstruirInvento);
            this.Controls.Add(this.btnAgrearIdea);
            this.Controls.Add(this.pictureBox2);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnAgrearIdea;
        private System.Windows.Forms.Button btnConstruirInvento;
        private System.Windows.Forms.Button btnIdeasFaltantes;
        private System.Windows.Forms.Button btnMasInventos;
        private System.Windows.Forms.TextBox txtCant;
        private System.Windows.Forms.TextBox txtAutor;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
    }
}

